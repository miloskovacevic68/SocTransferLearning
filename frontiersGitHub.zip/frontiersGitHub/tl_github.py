"""
Instance based transfer learning
Performs the experiments for Tables 2 and 3 in the Frontiers paper
"""

import os
import random
from itertools import product


import numpy as np
import torch
import torch.nn as tnn
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
from torch.multiprocessing import Pool
from torch.multiprocessing import Manager
from sklearn.neural_network import MLPClassifier

NUM_FEATURES = 5  # do not change!


def seed_torch(seed=2021):
    """
    Sets a random seed for all components of the experiment
    so that the results are the same when the experiment is repeated.
    """
    random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)


def r2(output, target):
    """
    Calculates Coefficient of Determination
    """
    target_mean = torch.mean(target)
    ss_tot = torch.sum((target - target_mean) ** 2)
    ss_res = torch.sum((target - output) ** 2)
    return (1 - ss_res / ss_tot).item()


def nrmse(output, target):
    """
    Calculates Normalized Mean Squared Error
    """
    return torch.sqrt(torch.mean((output - target) ** 2)).item() / torch.mean(target).item()


def nmae(output, target):
    """
    Calculates Normalized Mean Absolute Error
    """
    return torch.mean(torch.abs(output - target)).item() / torch.mean(target).item()


def mape(output, target):
    """
    Calculates Mean Absolute Percentage Error
    """
    return torch.mean(torch.abs((output - target)/target)).item()


class UnionSet(Dataset):
    """
    Dataset class which represents data from both source and target domain.
    Used for TL training in the phase !-a
    """

    def __init__(self, source_path, target_path, device, country):
        source_data = torch.from_numpy(
            np.loadtxt(source_path, dtype=np.float32, delimiter=",", skiprows=0)
        )
        source_data = source_data.to(device=device)
        xs = source_data[:, :-1]
        ds = torch.ones(xs.shape[0], 1)
        ys = source_data[:, -1].reshape(-1, 1)

        target_data = torch.from_numpy(
            np.loadtxt(target_path, dtype=np.float32, delimiter=",", skiprows=0)
        )
        target_data = target_data.to(device=device)

        xt = target_data[:, :-1]
        dt = torch.zeros(xt.shape[0], 1)
        yt = target_data[:, -1].reshape(-1, 1)

        self.country = country
        self.x, self.y = torch.cat([xs, xt], dim=0), torch.cat([ds, dt], dim=0)
        self.yy = torch.cat([ys, yt], dim=0)
        self.last = len(xs)

        # normalize data
        self.x = (self.x - self.x.mean(dim=0)) / self.x.std(dim=0)

    def __getitem__(self, idx):
        return self.x[idx], self.y[idx]

    def __len__(self):
        return len(self.y)


class SourceSet(Dataset):
    """
    Dataset class which represents source domain data.
    Used for TL training in phases 1-b and 2, and for classical model training.
    """

    def __init__(self, union_set, classifier=None):
        self.classifier = classifier
        self.x, self.y = union_set.x[:union_set.last], union_set.yy[:union_set.last]

        if classifier:
            pp = classifier.predict_proba(self.x.numpy())[:, 1:]
            self.p = torch.from_numpy(1 / pp)

    def __getitem__(self, idx):
        if self.classifier:
            return self.x[idx], self.y[idx], self.p[idx]
        else:
            return self.x[idx], self.y[idx]

    def __len__(self):
        return len(self.y)


class TargetSet(Dataset):
    """
    Dataset class which represents target domain data.
    """

    def __init__(self, union_set):
        self.x, self.y = union_set.x[union_set.last:], union_set.yy[union_set.last:]

    def __getitem__(self, idx):
        return self.x[idx], self.y[idx]

    def __len__(self):
        return len(self.y)


def train_classifier(union_set):
    """
    Trains a MLP Neural Network Classifier.
    Uses ReLU in hidden neurons.
    """
    x = union_set.x.numpy()
    y = union_set.y.numpy().ravel()
    cls = MLPClassifier(hidden_layer_sizes=(NUM_FEATURES, ), max_iter=1500, random_state=0)
    cls.fit(x, y)
    return cls


def transfer_learning_loss(y_pred, y, beta):
    """
    Modified regression loss function used to train the TL model in phase 2.
    """
    return torch.mean(beta * (y_pred - y)**2)


def experiment(device, in_queue, out_queue):
    """
    Performs the training and evaluation for classical and TL model in a leave-one-out-country procedure.
    """
    try:
        while True:

            country = in_queue.get(block=False)
            # common tasks
            union_ds = UnionSet(
                SOURCE_DIR + f"/{country}.csv",
                TARGET_DIR + f"/{country}.csv", device, country
            )

            # classical approach
            training_set = SourceSet(union_ds)
            test_set = TargetSet(union_ds)
            bcr2 = float("-inf")
            bcrmse, bcmae, bcmape = 0, 0, 0
            for epochs, lr, mom in list(product(*PARAMS_GRID.values())):
                seed_torch()
                train_loader = DataLoader(training_set, batch_size=BATCH_SIZE, shuffle=True)
                model = tnn.Sequential(
                    tnn.Linear(NUM_FEATURES, NUM_FEATURES), tnn.ReLU(),
                    tnn.Linear(NUM_FEATURES, 1),
                ).to(device)
                optimizer = torch.optim.SGD(model.parameters(), lr=lr, momentum=mom)
                loss = tnn.MSELoss()
                for _ in range(epochs):
                    for x, y in train_loader:
                        y_pr = model(x)
                        train_loss = loss(y_pr, y)
                        optimizer.zero_grad()
                        train_loss.backward()
                        optimizer.step()

                y_pr = model(test_set.x)
                _rmse, _mae, _r2, _mape = nrmse(y_pr, test_set.y), nmae(y_pr, test_set.y), \
                                          r2(y_pr, test_set.y), mape(y_pr, test_set.y)
                if _r2 > bcr2:
                    bcr2 = _r2
                    bcrmse = _rmse
                    bcmae = _mae
                    bcmape = _mape

            # transfer learning approach
            domain_classifier = train_classifier(union_ds)
            training_set = SourceSet(union_ds, classifier=domain_classifier)
            test_set = TargetSet(union_ds)
            btr2 = float("-inf")
            btrmse, btmae, btmape = 0, 0, 0
            for epochs, lr, mom in list(product(*PARAMS_GRID.values())):
                seed_torch()
                train_loader = DataLoader(training_set, batch_size=BATCH_SIZE, shuffle=True)
                model = tnn.Sequential(
                    tnn.Linear(NUM_FEATURES, NUM_FEATURES), tnn.ReLU(),
                    tnn.Linear(NUM_FEATURES, 1),
                ).to(device)
                optimizer = torch.optim.SGD(model.parameters(), lr=lr, momentum=mom)
                loss = transfer_learning_loss
                for _ in range(epochs):
                    for x, y, beta in train_loader:
                        y_pr = model(x)
                        train_loss = loss(y_pr, y, beta)
                        optimizer.zero_grad()
                        train_loss.backward()
                        optimizer.step()

                y_pr = model(test_set.x)
                _rmse, _mae, _r2, _mape = nrmse(y_pr, test_set.y), nmae(y_pr, test_set.y), \
                                          r2(y_pr, test_set.y), mape(y_pr, test_set.y)
                if _r2 > btr2:
                    btr2 = _r2
                    btrmse = _rmse
                    btmae = _mae
                    btmape = _mape

            out_queue.put((country, bcrmse, bcmae, bcr2, bcmape, btrmse, btmae, btr2, btmape))
            print("Finished", country)
    except:
        pass


if __name__ == "__main__":
    # Here put the number of processes!
    CPU_PROCESSES = 8
    # Here put the params for the regression network
    PARAMS_GRID = {"epochs": [300, 500, 700], "lr": [0.001, 0.0001], "mom": [0.5]}
    # Full gradient descent (do not change)
    BATCH_SIZE = 10_000

    # Here put the path to the source domain dir
    SOURCE_DIR = "/home/milos/Working/ceres/soc/frontiersGitHub/GrasslandSource"
    # SOURCE_DIR = "/home/milos/Working/ceres/soc/frontiersGitHub/CroplandSource"

    # Here put the path to the target domain dir
    TARGET_DIR = "/home/milos/Working/ceres/soc/frontiersGitHub/CroplandTarget"

    CPU = torch.device("cpu")
    COUNTRIES = [
         'Czech_Republic', 'Austria', 'Sweden', 'Bulgaria', 'France', 'United_Kingdom',
         'Spain', 'Romania', 'Italy', 'Poland', 'Greece', 'Germany'
    ]

    crmse, trmse, cmae, tmae, cr2, tr2, cmape, tmape = 0, 0, 0, 0, 0, 0, 0, 0

    cnt_queue = Manager().Queue()
    for c in COUNTRIES:
        cnt_queue.put(c)
    res_queue = Manager().Queue()

    with Pool(processes=CPU_PROCESSES) as p:
        p.starmap(experiment, [(CPU, cnt_queue, res_queue) for _ in range(CPU_PROCESSES)])

    while not res_queue.empty():
        cntry, c1, c2, c3, c4, t1, t2, t3, t4 = res_queue.get()
        print(cntry)
        print(f"Classical NRMSE: {np.round(c1, 2)} NMAE: {np.round(c2, 2)} R2: {np.round(c3, 2)} MAPE: {np.round(c4, 2)}")
        print(f"Transfer NRMSE: {np.round(t1, 2)} NMAE: {np.round(t2, 2)} R2: {np.round(t3, 2)} MAPE: {np.round(t4, 2)}")
        crmse += c1
        cmae += c2
        cr2 += c3
        cmape += c4
        trmse += t1
        tmae += t2
        tr2 += t3
        tmape += t4

    print(f"Average Classical NRMSE: {np.round(crmse/len(COUNTRIES), 2)} NMAE: {np.round(cmae/len(COUNTRIES), 2)} R2: {np.round(cr2/len(COUNTRIES), 2)} MAPE: {np.round(cmape/len(COUNTRIES), 2)}")
    print(f"Average Transfer NRMSE: {np.round(trmse / len(COUNTRIES), 2)} NMAE: {np.round(tmae / len(COUNTRIES), 2)} R2: {np.round(tr2 / len(COUNTRIES), 2)} MAPE: {np.round(tmape/len(COUNTRIES), 2)}")

