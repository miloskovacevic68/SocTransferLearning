"""
Calculates Bhattacharyya distance between the source and the target domain datasets.
"""

import numpy as np


def discretize(X, low, high, num_int):
    """
    Returns a discrete probability tensor for a joint probability P(X).
    Uses adaptable step for each dimension. The step is defined with a low and high value
    and a number of intervals per each dimension.
    """

    N, n = X.shape
    assert low.shape == high.shape
    assert high.shape == num_int.shape
    assert num_int.shape[0] == n
    # Initializing deltas and bounds for variables
    P = np.zeros(num_int)
    delta = (high - low) / num_int
    total_in, total_out = 0, 0
    low_bound = [
        np.array([low[j] + i * delta[j] for i in range(num_int[j])])
        for j in range(n)
    ]
    high_bound = [
        np.array([low[j] + i * delta[j] for i in range(1, num_int[j] + 1)])
        for j in range(n)
    ]
    # frequency counting
    for i in range(N):
        ind = [None for _ in range(n)]
        for j in range(n):
            mask = (X[i, j] >= low_bound[j]) & (X[i, j] < high_bound[j])
            if np.any(mask):
                ind[j] = np.argmax(mask)
            else:
                break

        if None in ind:
            total_out += 1
        else:
            P[tuple(ind)] += 1
            total_in += 1

    return P / total_in, total_out


if __name__ == "__main__":

    COUNTRIES = [
        'Czech_Republic', 'Austria', 'Sweden', 'Bulgaria', 'France', 'United_Kingdom',
        'Spain', 'Romania', 'Italy', 'Poland', 'Greece', 'Germany'
    ]

    # Here put source domain dir
    SOURCE_DIR = "/home/milos/Working/ceres/soc/frontiersGitHub/GrasslandSource"
    # SOURCE_DIR = "/home/milos/Working/ceres/soc/frontiersGitHub/CroplandSource"

    # Here put target domain dir
    TARGET_DIR = "/home/milos/Working/ceres/soc/frontiersGitHub/CroplandTarget"

    distBD = []
    # DO NOT CHANGE: obtained from the stats of grassland + cropland samples!
    low_vals = np.array([0.1, 3.29, 3.1, 0.2, 0.0217])
    high_vals = np.array([38.51, 10.371, 10.01, 7776.21, 5.997])
    num_intervals = np.array([50, 20, 20, 100, 75])

    for c in COUNTRIES:
        X1 = np.loadtxt(f"{SOURCE_DIR}/{c}.csv", skiprows=0, delimiter=",")[:, :5]
        X2 = np.loadtxt(f"{TARGET_DIR}/{c}.csv", skiprows=0, delimiter=",")[:, :5]

        P1, o1 = discretize(X1, low_vals, high_vals, num_intervals)
        P2, o2 = discretize(X2, low_vals, high_vals, num_intervals)
        distBD.append((-np.log(np.sqrt(P1 * P2).sum()), c))

    distBD.sort()
    for d, c in distBD:
        print(c, np.round(d, 2))





